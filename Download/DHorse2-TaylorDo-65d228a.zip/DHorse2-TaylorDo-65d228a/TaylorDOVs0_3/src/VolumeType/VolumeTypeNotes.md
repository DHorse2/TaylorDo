# Script: VolumeTypeSys
#
# Syntax (how to use this)
# Name("C:") or Name("D:") or Name("G:")
# Name("C") or Name("D") or Name("G")
#
# You can also use the volume label:
# Label("\\?\Volume{00099999-0000-0000-0000-100000000000}\")
# if unsed: 
# Name("SKIP")
Name("F:")
