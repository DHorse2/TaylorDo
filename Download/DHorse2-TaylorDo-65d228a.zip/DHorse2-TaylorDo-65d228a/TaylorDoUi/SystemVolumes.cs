﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Source GitHub Milosz Krajewski
// <script src="https://gist.github.com/MiloszKrajewski/352dc8b8eb132d3a2bc7.js"></script>
//
namespace TaylorDoUi
{
    class SystemVolumes
    {

        SystemVolumes{
    }
}
