# Issue Reporting

Public issues can be reported on GitHub via https://github.com/phoronix-test-suite/phoronix-test-suite/issues

Security issues can be reported via email to security@phoronix-test-suite.com
