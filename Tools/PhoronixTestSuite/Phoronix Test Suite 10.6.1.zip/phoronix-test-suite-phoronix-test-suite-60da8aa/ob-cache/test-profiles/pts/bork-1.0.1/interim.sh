#!/bin/sh

rm -f encryptfile.bork
