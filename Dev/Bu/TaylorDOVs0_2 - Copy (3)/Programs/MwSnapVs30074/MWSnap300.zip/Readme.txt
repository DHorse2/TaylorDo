MWSnap v.3.0.0.74

Copyright (c) 2000, 2002 Mirek W�jtowicz, Lublin, Poland
All rights reserved.

MWSnap is free for both commercial and non-commercial use.
You are free to put this program on a CD-ROM, but if you do so
please send me a notification (and a copy of the CD, if possible.)
And of course spread this program complete with all files.


Contents
========
 - General description
 - selected MWSnap features
 - Installation and updating
 - Standard Disclaimer
 - Contacting the author


General description
===================

MWSnap is a small yet powerful Windows program for snapping
(capturing) images from selected parts of the screen. Current
version is capable of capturing the whole desktop, a highlighted
window, an active menu, or a fixed or free rectangular part of
the screen. MWSnap handles 5 most popular graphics formats and
contains important graphical tools: a zooming box, a ruler, a color
picker and a windows spy.

MWSnap runs under any 32-bit Windows. It does not require
installation and does not need any special dlls, drivers or
system files which can mess up your system.


MWSnap selected features
========================

- 5 snapping modes.
- Support for BMP, JPG, PNG, TIFF and GIF formats, with selected
  color depth and quality settings.
- System-wide hotkeys.
- Clipboard copy and paste.
- Auto-saving, auto-printing.
- Various picture transformations.
- Undo and redo.
- Auto-start with Windows.
- Minimizing to system tray.
- An auto-extending list of fixed sizes, perfect for snapping
  images for icons and glyphs.
- A zoom tool for magnifying selected parts of the screen.
- A ruler tool for measuring screen objects lengths.
- A color picker (within the zoom tool).
- Fast picture viewer.
- A window info tool.
- Configurable user interface.
- Multilingual versions.
- And more...


Installation and updating
=========================

Setup version (MWSnap300.exe)
- Execute the setup file, select your preferred installation
  language and follow on-screen instructions.

ZIPped version (MWSnap300.zip)
- Create a folder for the program and unzip the package into
  it. The program is ready for use!

To update your existing version just install the program
into the same folder.


Standard Disclaimer
===================

THIS SOFTWARE AND THE ACCOMPANYING FILES ARE PROVIDED "AS IS"
AND WITHOUT WARRANTIES AS TO PERFORMANCE OF MERCHANTABILITY OR
ANY OTHER WARRANTIES WHETHER EXPRESSED OR IMPLIED. The user must
assume the entire risk of using the program.


Contacting the author
=====================

e-mail:
  info@mirekw.com
  mirwoj@life.pl

WWW:
  http://www.mirekw.com
  http://www.mirwoj.opus.chelm.pl/

I appreciate and welcome any comments, enhancement requests,
improvement suggestions and bug reports that you may have.
